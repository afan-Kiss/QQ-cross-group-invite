<?php
/*
 作者：Daen
 QQ:1330166565
 2021年6月28日
*/
class Api{//MyQQ Api，这里只写了两个作为例子，文档地址https://www.kancloud.cn/daen/myqq/2233670
	//发送消息
	public static function Api_SendMsgEx($c1,$c2,$c3,$c4,$c5,$c6,$c7){
		global $g_token,$g_url;
		$params = array(
			"c1"=>$c1,
			"c2"=>$c2,
			"c3"=>$c3,
			"c4"=>$c4,
			"c5"=>$c5,
			"c6"=>$c6,
			"c7"=>$c7
		);
		$return = array(
			"function"=>"Api_SendMsgEx",
			"token"=>$g_token,
			"params"=>$params,
		);
		curl_post($g_url,json_encode($return));
	}
	//发送XML
	public static function Api_SendXml($c1,$c2,$c3,$c4,$c5,$c6,$c7){
		global $g_token,$g_url;
		$params = array(
			"c1"=>$c1,
			"c2"=>$c2,
			"c3"=>$c3,
			"c4"=>$c4,
			"c5"=>$c5,
			"c6"=>$c6,
			"c7"=>$c7
		);
		$return = array(
			"function"=>"Api_SendXml",
			"token"=>$g_token,
			"params"=>$params,
		);
		curl_post($g_url,json_encode($return));
	}
	//输出日志
	public static function Api_OutPut($c1){
		global $g_token,$g_url;
		$params = array(
			"c1"=>$c1
		);
		$return = array(
			"function"=>"Api_OutPut",
			"token"=>$g_token,
			"params"=>$params,
		);
		curl_post($g_url,json_encode($return));
	}
}
class Text{//MyQQ 文本代码，这里只写了两个作为例子，文档地址https://www.kancloud.cn/daen/myqq/2233669
	//艾特
	public static function Text_At($c1){
		return '[@'.$c1.']';
	}
	//换行
	public static function Text_Hr(){
		return '[\n]';//如果使用此方法，那么可以用[\n]作为换行，否则直接在文本中请使用\n
	}
}
function curl_post($url,$post=0,$type=0){//GET、POST网络请求
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL,$url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_TIMEOUT, 10);	
	if($post){
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
	}
	curl_setopt($ch, CURLOPT_HEADER, $type);
	curl_setopt($ch, CURLINFO_HEADER_OUT, true);
	curl_setopt($ch, CURLOPT_AUTOREFERER, false);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
	$ret = curl_exec($ch);
	curl_close($ch);
	return $ret;
}


//返回1（#消息处理_继续），其他插件可继续处理此条消息
//返回2（#消息处理_拦截），拦截信息，此条消息不再分发给其他插件，其他插件将不能再处理
function ret($status){
	$return = array(
		"status"=>$status,
	);
	return json_encode($return);
}
?>