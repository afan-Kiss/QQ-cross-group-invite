<?php
/*
 作者：Daen
 QQ:1330166565
 2021年6月28日
*/
header('Content-type: application/json');
include("module.php");
$g_token = "666";//修改为和HTTPAPI插件上的TOKEN一致
$g_url = "http://localhost:10002/MyQQHTTPAPI";//修改为和HTTPAPI插件上的一致
$json_string = file_get_contents('php://input');
$array = json_decode($json_string, true);
$array['MQ_msg'] = urldecode($array['MQ_msg']);
echo MQ_Event($array['MQ_robot'],$array['MQ_type'],$array['MQ_type_sub'],$array['MQ_fromID'],$array['MQ_fromQQ'],$array['MQ_passiveQQ'],$array['MQ_msg'],$array['MQ_msgSeq'],$array['MQ_msgID'],$array['MQ_msgData']);

//消息处理，参数说明文档https://www.myqqx.net/MyQQ/6.HTTPAPI/2.%E8%AE%BE%E7%BD%AE%E8%AF%B4%E6%98%8E.html
function MQ_Event($MQ_robot,$MQ_type,$MQ_type_sub,$MQ_fromID,$MQ_fromQQ,$MQ_passiveQQ,$MQ_msg,$MQ_msgSeq,$MQ_msgID,$MQ_msgData){
	//在此函数里编写您的相关代码
	//Api调用示例：Api::Api_SendMsgEx($MQ_robot,0,$MQ_type,$MQ_fromID,$MQ_fromQQ,$MQ_msg,0);
	//文本代码调用示例：Text::Text_At('1330166565');
	if($MQ_type==1){//好友消息
		if($MQ_msg=="你好"){
			Api::Api_SendMsgEx($MQ_robot,0,$MQ_type,$MQ_fromID,$MQ_fromQQ,$MQ_msg,0);
			return ret(1);
		}
	}
	if($MQ_type==2){//群消息
		if($MQ_msg=="测试"){
			Api::Api_OutPut('输出了一条日志哦');
			//在文本中，可以使用Text::Text_Hr()，也可以使用\n
			Api::Api_SendMsgEx($MQ_robot,0,$MQ_type,$MQ_fromID,$MQ_fromQQ,Text::Text_At('1330166565').Text::Text_Hr()."测试成功\n换行测试1",0);
			return ret(1);
		}
		if($MQ_msg=="发送XML"){//将xml里的单引号全部替换成双引号即可
			$xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><msg templateID="123" url="https://blog.csdn.net/daijiguo/article/details/50630733" serviceID="33" action="web" actionData="" brief="【链接】测试" flag="8"><item layout="2"><picture cover="https://www.baidu.com/img/flexible/logo/pc/result.png"/><title>【MYQQHTTPAPI】</title><summary>【XML测试】</summary></item></msg>';
			Api::Api_SendXml($MQ_robot,0,$MQ_type,$MQ_fromID,$MQ_fromQQ,$xml,0);
			return ret(1);
		}
	}
	
	return ret(1);
}
?>
