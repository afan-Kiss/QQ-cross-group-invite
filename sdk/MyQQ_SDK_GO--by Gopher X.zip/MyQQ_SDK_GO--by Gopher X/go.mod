module go_code/MyQQ_SDK_GO

go 1.17

require golang.org/x/text v0.3.5
