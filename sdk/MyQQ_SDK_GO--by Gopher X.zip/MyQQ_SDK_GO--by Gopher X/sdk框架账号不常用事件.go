package main

import (
	"go_code/MyQQ_SDK_GO/bin/consts"
	"go_code/MyQQ_SDK_GO/bin/onebot"
)

func 添加了一个新的帐号(d onebot.MQEvent) int {
	// api.A输出日志("添加了一个新的帐号" + d.MQ_触发对象_主动)
	return consts.MT_消息处理_继续
}
func QQ登录完成(d onebot.MQEvent) int {
	// api.A输出日志(d.MQ_触发对象_主动 + "登录完成")
	return consts.MT_消息处理_继续
}
func QQ被手动离线(d onebot.MQEvent) int {
	// api.A输出日志(d.MQ_触发对象_主动 + "被手动离线")
	return consts.MT_消息处理_继续
}
func QQ被强制离线(d onebot.MQEvent) int {
	// api.A输出日志(d.MQ_触发对象_主动 + "被强制离线 估计冻结了或者被挤下线了")
	return consts.MT_消息处理_继续
}
func QQ长时间无响应或掉线(d onebot.MQEvent) int {
	// api.A输出日志(d.MQ_触发对象_主动 + "QQ长时间无响应或掉线")
	return consts.MT_消息处理_继续
}
func 其他设备上线(d onebot.MQEvent) int {
	// 请自行解析 MQ_消息内容 ： {"deviceID": "809020","flag": "0380900001010761A1F7500E149A6BO00A04"}
	// api.A输出日志(d.MQ_触发对象_主动 + "在其他设备上线")
	// JSON.取通用属性 (“deviceID”), JSON.取通用属性 (“flag”))
	return consts.MT_消息处理_继续
}
func 其他设备下线(d onebot.MQEvent) int {
	//请自行解析 MQ_消息内容 ： {"deviceID": "809020","flag": "0380900001010761A1F7500E149A6BO00A04"}
	// api.A输出日志(d.MQ_触发对象_主动 + "在其他设备下线")
	return consts.MT_消息处理_继续
}
func 未定义(d onebot.MQEvent) int {
	// api.A输出日志("未定义的信息")
	return consts.MT_消息处理_继续
}
