package main

import (
	"go_code/MyQQ_SDK_GO/bin/consts"
	"go_code/MyQQ_SDK_GO/bin/onebot"
	"time"
)

func 被单向添加好友(d onebot.MQEvent) int {
	// api.A输出日志(d.MQ_机器人QQ + "被" + d.MQ_触发对象_主动 + "添加单向好友")
	return consts.MT_消息处理_继续
}

func 被请求添加好友(d onebot.MQEvent) int {
	// api.A输出日志(d.MQ_机器人QQ + "被" + d.MQ_触发对象_主动 + "请求添加好友 附加理由:" + d.MQ_消息内容)
	// api.A置好友验证事件(d.MQ_机器人QQ, d.MQ_触发对象_主动, consts.MT_事件处理_同意, "啊哦")
	return consts.MT_消息处理_继续
}

func 被同意加为好友(d onebot.MQEvent) int {
	// api.A输出日志(d.MQ_机器人QQ + "被" + d.MQ_触发对象_主动 + "被同意加为好友")
	return consts.MT_消息处理_继续
}

func 被拒绝加为好友(d onebot.MQEvent) int {
	// api.A输出日志(d.MQ_机器人QQ + "被" + d.MQ_触发对象_主动 + "被拒绝加为好友")
	return consts.MT_消息处理_继续
}

func 好友状态改变(d onebot.MQEvent) int {
	// api.A输出日志("好友:" + api.A取昵称(d.MQ_机器人QQ, d.MQ_触发对象_主动) + "(" + d.MQ_触发对象_主动 + ") 状态改变为 " + d.MQ_消息内容)
	return consts.MT_消息处理_继续
}

func 被删除好友(d onebot.MQEvent) int {
	// api.A输出日志("被" + api.A取昵称(d.MQ_机器人QQ, d.MQ_触发对象_主动) + "(" + d.MQ_触发对象_主动 + ")删除了好友")
	return consts.MT_消息处理_继续
}

func 好友签名变更(d onebot.MQEvent) int {
	// api.A输出日志("好友 " + api.A取昵称(d.MQ_机器人QQ, d.MQ_触发对象_主动) + "(" + d.MQ_触发对象_主动 + ")的签名变更为 " + d.MQ_消息内容)
	return consts.MT_消息处理_继续
}
func 某人申请加入群(d onebot.MQEvent) int {
	// api.A输出日志(d.MQ_触发对象_主动 + "请求加入群" + d.MQ_消息来源 + " 附加理由:" + d.MQ_消息内容)
	// api.A置群验证事件(d.MQ_机器人QQ, d.MQ_原始信息, consts.MT_事件处理_拒绝, "气死你啊", 0)
	return consts.MT_消息处理_继续
}
func 某人被邀请加入群(d onebot.MQEvent) int {
	// api.A输出日志(d.MQ_触发对象_主动 + "请求加入群" + d.MQ_消息来源 + " 附加理由:" + d.MQ_消息内容)
	// api.A置群验证事件(d.MQ_机器人QQ, d.MQ_原始信息, consts.MT_事件处理_拒绝, "气死你啊", 0)
	return consts.MT_消息处理_继续
}
func 我被邀请加入群(d onebot.MQEvent) int {
	// api.A输出日志("我被" + d.MQ_触发对象_主动 + "邀请加入群" + d.MQ_消息来源)
	// api.A置群验证事件(d.MQ_机器人QQ, d.MQ_原始信息, consts.MT_事件处理_拒绝, "就不哈哈", 0)
	// api.A置群验证事件(d.MQ_机器人QQ, d.MQ_原始信息, consts.MT_事件处理_同意, "", 0)
	return consts.MT_消息处理_继续
}
func 某人已被邀请入群(d onebot.MQEvent) int {
	// 一般为群主或者管理员邀请的
	// api.A输出日志(d.MQ_触发对象_被动 + "已被" + d.MQ_触发对象_主动 + "邀请加入群" + d.MQ_消息来源)
	return consts.MT_消息处理_继续
}
func 某人被批准加入了群(d onebot.MQEvent) int {
	// api.A输出日志(api.A取昵称(d.MQ_机器人QQ, d.MQ_触发对象_被动) + "(" + d.MQ_触发对象_被动 + ")被" + api.A取昵称(d.MQ_机器人QQ, d.MQ_触发对象_主动) + "(" + d.MQ_触发对象_主动 + ")批准加入了群")
	return consts.MT_消息处理_继续
}
func 某人退出群(d onebot.MQEvent) int {
	// api.A输出日志(api.A取昵称(d.MQ_机器人QQ, d.MQ_触发对象_主动) + "(" + d.MQ_触发对象_主动 + ")退出了群")
	return consts.MT_消息处理_继续
}
func 某人被管理移除群(d onebot.MQEvent) int {
	// api.A输出日志(api.A取昵称(d.MQ_机器人QQ, d.MQ_触发对象_被动) + "(" + d.MQ_触发对象_被动 + ")被" + api.A取昵称(d.MQ_机器人QQ, d.MQ_触发对象_主动) + "(" + d.MQ_触发对象_主动 + ")移除了群")
	return consts.MT_消息处理_继续
}
func 某群被解散(d onebot.MQEvent) int {
	// api.A输出日志("群" + d.MQ_消息来源 + "被群主:" + api.A取昵称(d.MQ_机器人QQ, d.MQ_触发对象_主动) + "(" + d.MQ_触发对象_主动 + ")解散了")
	return consts.MT_消息处理_继续
}
func 某人成为管理(d onebot.MQEvent) int {
	// api.A输出日志("群" + d.MQ_消息来源 + "成员:" + api.A取昵称(d.MQ_机器人QQ, d.MQ_触发对象_被动) + "(" + d.MQ_触发对象_被动 + ")成为了管理员")
	return consts.MT_消息处理_继续
}
func 某人被取消管理(d onebot.MQEvent) int {
	// api.A输出日志("群" + d.MQ_消息来源 + "成员:" + api.A取昵称(d.MQ_机器人QQ, d.MQ_触发对象_被动) + "(" + d.MQ_触发对象_被动 + ")被取消了管理员")
	return consts.MT_消息处理_继续
}
func 群名片变动(d onebot.MQEvent) int {
	// api.A输出日志(api.A取群名片(d.MQ_机器人QQ, d.MQ_消息来源, d.MQ_触发对象_主动) + "(" + d.MQ_触发对象_主动 + ")的群名片变更为:" + d.MQ_消息内容)
	return consts.MT_消息处理_继续
}
func 群名变动(d onebot.MQEvent) int {
	// api.A输出日志(d.MQ_机器人QQ + "群名变动->" + d.MQ_消息来源 + "->" + d.MQ_消息内容)
	return consts.MT_消息处理_继续
}
func 群公告变动(d onebot.MQEvent) int {
	// api.A输出日志(d.MQ_机器人QQ + "群" + d.MQ_消息来源 + "管理:" + api.A取昵称(d.MQ_机器人QQ, d.MQ_触发对象_主动) + "(" + d.MQ_触发对象_主动 + ")发布了新公告:" + "\n" + d.MQ_消息内容)
	return consts.MT_消息处理_继续
}
func 说说被评论(d onebot.MQEvent) int {
	// api.A输出日志(d.MQ_机器人QQ + "说说被对象->" + d.MQ_触发对象_主动 + "评论")
	return consts.MT_消息处理_继续
}
func 好友正在输入(d onebot.MQEvent) int {
	// api.A输出日志(d.MQ_机器人QQ + "好友->" + d.MQ_触发对象_主动 + "正在输入")
	return consts.MT_消息处理_继续
}
func 好友今天首次发起会话(d onebot.MQEvent) int {
	// api.A输出日志(d.MQ_机器人QQ + "好友->" + d.MQ_触发对象_主动 + "今天在电脑上首次发起了好友聊天信息/打开聊天框")
	return consts.MT_消息处理_继续
}
func 被好友抖动(d onebot.MQEvent) int {
	// api.A输出日志(d.MQ_机器人QQ + "好友->" + d.MQ_触发对象_主动 + "发送了一个抖动")
	return consts.MT_消息处理_继续
}
func 好友文件接收(d onebot.MQEvent) int {
	// api.A输出日志(d.MQ_机器人QQ + "收到好友->" + d.MQ_触发对象_主动 + "发来的文件->" + d.MQ_消息内容)
	return consts.MT_消息处理_继续
}
func 群文件接收(d onebot.MQEvent) int {
	// api.A输出日志(d.MQ_机器人QQ + "收到群->" + d.MQ_消息来源 + "里->" + d.MQ_触发对象_主动 + "发来的文件->" + d.MQ_消息内容 + "->" + strconv.Itoa(int(d.MQ_消息序号)) + "->" + strconv.Itoa(int(d.MQ_消息ID)))
	time.Sleep(time.Second * 2)
	// api.A撤回消息(d.MQ_机器人QQ, d.MQ_消息来源, strconv.Itoa(int(d.MQ_消息序号)), strconv.Itoa(int(d.MQ_消息ID)))
	return consts.MT_消息处理_继续
}
func 对象被禁言(d onebot.MQEvent) int {
	// api.A输出日志(d.MQ_机器人QQ + "群->" + d.MQ_消息来源 + "->" + d.MQ_触发对象_被动 + "被" + d.MQ_触发对象_主动 + "禁言->" + d.MQ_消息内容 + "秒")
	return consts.MT_消息处理_继续
}
func 对象被解除禁言(d onebot.MQEvent) int {
	// api.A输出日志(d.MQ_机器人QQ + "群->" + d.MQ_消息来源 + "->" + d.MQ_触发对象_被动 + "被" + d.MQ_触发对象_主动 + "解除禁言")
	return consts.MT_消息处理_继续
}
func 群管开启全群禁言(d onebot.MQEvent) int {
	// api.A输出日志(d.MQ_机器人QQ + "群->" + d.MQ_消息来源 + "->" + d.MQ_触发对象_主动 + "开启了全群禁言")
	return consts.MT_消息处理_继续
}
func 群管关闭全群禁言(d onebot.MQEvent) int {
	// api.A输出日志(d.MQ_机器人QQ + "群->" + d.MQ_消息来源 + "->" + d.MQ_触发对象_主动 + "关闭了全群禁言")
	return consts.MT_消息处理_继续
}
func 群管开启匿名聊天(d onebot.MQEvent) int {
	// api.A输出日志(d.MQ_机器人QQ + "群->" + d.MQ_消息来源 + "->" + d.MQ_触发对象_主动 + "开启了匿名聊天")
	return consts.MT_消息处理_继续
}
func 群管关闭匿名聊天(d onebot.MQEvent) int {
	// api.A输出日志(d.MQ_机器人QQ + "群->" + d.MQ_消息来源 + "->" + d.MQ_触发对象_主动 + "关闭了匿名聊天")
	return consts.MT_消息处理_继续
}
func 好友撤回消息(d onebot.MQEvent) int {
	// api.A输出日志(d.MQ_机器人QQ + "好友->" + d.MQ_触发对象_主动 + "撤回了一条消息->" + "消息序号为->" + strconv.Itoa(int(d.MQ_消息序号)) + "消息ID为->" + strconv.Itoa(int(d.MQ_消息ID)))
	return consts.MT_消息处理_继续
}
func 群撤回消息(d onebot.MQEvent) int {
	// api.A输出日志(d.MQ_机器人QQ + "群->" + d.MQ_消息来源 + "->" + d.MQ_触发对象_主动 + "撤回了一条消息->" + "消息序号为->" + strconv.Itoa(int(d.MQ_消息序号)) + "消息ID为->" + strconv.Itoa(int(d.MQ_消息ID)))
	return consts.MT_消息处理_继续
}
func 好友视频接收(d onebot.MQEvent) int {
	// api.A输出日志(d.MQ_机器人QQ + "收到好友->" + d.MQ_触发对象_主动 + "发来的视频->" + d.MQ_消息内容)
	return consts.MT_消息处理_继续
}
func 群视频接收(d onebot.MQEvent) int {
	// api.A输出日志(d.MQ_机器人QQ + "收到群->" + d.MQ_消息来源 + "里->" + d.MQ_触发对象_主动 + "发来的视频->" + d.MQ_消息内容 + "->" + strconv.Itoa(int(d.MQ_消息序号)) + "->" + strconv.Itoa(int(d.MQ_消息ID)))
	time.Sleep(time.Second * 2)
	// api.A撤回消息(d.MQ_机器人QQ, d.MQ_消息来源, strconv.Itoa(int(d.MQ_消息序号)), strconv.Itoa(int(d.MQ_消息ID)))
	return consts.MT_消息处理_继续
}
func 好友语音接收(d onebot.MQEvent) int {
	// api.A输出日志(d.MQ_机器人QQ + "收到好友->" + d.MQ_触发对象_主动 + "发来的语音->" + d.MQ_消息内容)
	return consts.MT_消息处理_继续
}
func 群语音接收(d onebot.MQEvent) int {
	// api.A输出日志(d.MQ_机器人QQ + "收到群->" + d.MQ_消息来源 + "里->" + d.MQ_触发对象_主动 + "发来的语音->" + d.MQ_消息内容 + "->" + strconv.Itoa(int(d.MQ_消息序号)) + "->" + strconv.Itoa(int(d.MQ_消息ID)))
	time.Sleep(time.Second * 2)
	// api.A撤回消息(d.MQ_机器人QQ, d.MQ_消息来源, strconv.Itoa(int(d.MQ_消息序号)), strconv.Itoa(int(d.MQ_消息ID)))
	return consts.MT_消息处理_继续
}
func 群消息被设置为精华(d onebot.MQEvent) int {
	// api.A输出日志("群->" + d.MQ_消息来源 + "中的->" + d.MQ_触发对象_被动 + "的消息被->" + d.MQ_触发对象_主动 + "设为精华，消息序号->" + strconv.Itoa(int(d.MQ_消息序号)) + "，消息ID->" + strconv.Itoa(int(d.MQ_消息ID)))
	return consts.MT_消息处理_继续
}
func 群消息被取消精华(d onebot.MQEvent) int {
	// api.A输出日志("群->" + d.MQ_消息来源 + "中的->" + d.MQ_触发对象_被动 + "的消息被->" + d.MQ_触发对象_主动 + "取消设为精华，消息序号->" + strconv.Itoa(int(d.MQ_消息序号)) + "，消息ID->" + strconv.Itoa(int(d.MQ_消息ID)))
	return consts.MT_消息处理_继续
}
func 收到财付通转账(d onebot.MQEvent) int {
	// 请自行解析json：MQ_消息内容
	// 未收款
	// {"id":"101000026901502107061428363313","status":"0","money":"未收款无法查看","msg":"测试"}

	// 已收款
	// "id":"101000026901502107061428363613","status":"1","money":"0.01","msg":"测试一下"}

	// api.A输出日志(d.MQ_机器人QQ + "收到来自->" + d.MQ_触发对象_主动 + "的财付通转账->" + d.MQ_消息内容)
	return consts.MT_消息处理_继续
}
func 收到群聊红包(d onebot.MQEvent) int {
	// 请自行解析json：MQ_消息内容
	// {"type":"12","red_id":"10000320012107063900101419587000","key":"96 D5 C0 44 CE F0 FE E7 9C 32 AF 85 CB 89 80 E8 82 6E 47 C3 40 FA 8C 43 54 0F AD 59 34 CC 0D DE","red_Key":"d7a4d872dd22378ee9148648319aeb6c","red_Skey":"c6a4ecf73599a65a4553c150beac7224","title":"大吉大利","nick":"鸡丁","p_skey":"LjM*RkjOH1fBicw8zs5vp8LID2rp4mP4yLz2xPLoEQw_"}
	// 说明：口令红包时，title为口令
	// type说明：12=口令红包，6=拼手气，4=普通红包
	// api.A输出日志(d.MQ_机器人QQ + "收到群->" + d.MQ_消息来源 + "里->" + d.MQ_触发对象_主动 + "发来的红包->" + d.MQ_消息内容 + "->" + strconv.Itoa(int(d.MQ_消息序号)) + "->" + strconv.Itoa(int(d.MQ_消息ID)))
	time.Sleep(time.Second * 2)
	// api.A撤回消息(d.MQ_机器人QQ, d.MQ_消息来源, strconv.Itoa(int(d.MQ_消息序号)), strconv.Itoa(int(d.MQ_消息ID)))
	return consts.MT_消息处理_继续
}
func 收到私聊红包(d onebot.MQEvent) int {
	// api.A输出日志(d.MQ_机器人QQ + "收到好友->" + d.MQ_触发对象_主动 + "发来的红包->" + d.MQ_消息内容)
	return consts.MT_消息处理_继续
}
func 群聊红包被领取(d onebot.MQEvent) int {
	// 可获得：MQ_消息内容（MQ_msg）
	// 调用 MyQQ_HB_Detial 解析领取详情即可
	// {"key":"96 D5 C0 44 CE F0 FE E7 9C 32 AF 85 CB 89 80 E8 82 6E 47 C3 40 FA 8C 43 54 0F AD 59 34 CC 0D DE","red_Key":"d7a4d872dd22378ee9148648319aeb6c","red_Skey":"c6a4ecf73599a65a4553c150beac7224","nick":"鸡丁","p_skey":"LjM*RkjOH1fBicw8zs5vp8LID2rp4mP4yLz2xPLoEQw_"}
	// api.A输出日志("群->" + d.MQ_消息来源 + "内的->" + d.MQ_触发对象_主动 + "领取了机器人->" + d.MQ_机器人QQ + "发的红包")
	return consts.MT_消息处理_继续
}
func 私聊红包被领取(d onebot.MQEvent) int {
	// 暂未开放
	return consts.MT_消息处理_继续
}

//func (d onebot.MQEvent) int {

//	return consts.MT_消息处理_继续
//}
