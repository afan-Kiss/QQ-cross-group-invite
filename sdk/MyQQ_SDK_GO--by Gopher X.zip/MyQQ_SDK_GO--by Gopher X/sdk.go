package main

import (
	"go_code/MyQQ_SDK_GO/bin/api"
	"go_code/MyQQ_SDK_GO/bin/consts"
	"go_code/MyQQ_SDK_GO/bin/onebot"
	"go_code/MyQQ_SDK_GO/bin/ui"
)

// 插件信息
var (
	//插件名称
	插件名称 = "aGoDLL"
	//插件版本
	插件版本 = "1.0.0"
	//插件作者
	插件作者 = "Gopher X"
	//插件说明
	插件说明 = " QQ : 1071761135 "

	// 用于插件生成文件存放 【\data\plugin\插件名称】 末尾不带\
	应用目录 = 初始化应用目录()
)

// 初始化函数
func 初始化函数() {

	// 插件载入时会执行这里

	// 初始化代码请写在这里

}

// 设置按钮
func 设置被按下() {

	// 点击设置后执行此处代码

	ui.MessageBoxPlain("启动结果", "插件启动成功")

}

// 常用事件
func 收到好友消息(d onebot.MQEvent) int {
	// api.A输出日志("收到好友->" + d.MQ_消息来源 + "的信息:" + d.MQ_消息内容)
	// 私聊复读机
	api.A发送消息(d.MQ_机器人QQ, d.MQ_消息类型, d.MQ_消息来源, d.MQ_消息来源, d.MQ_消息内容, 0, 0, 0)
	return consts.MT_消息处理_继续
}

func 收到群消息(d onebot.MQEvent) int {

	// api.A输出日志("收到群->" + d.MQ_消息来源 + " 成员->" + d.MQ_触发对象_主动 + "的信息:" + d.MQ_消息内容)
	return consts.MT_消息处理_继续
}

func 收到讨论组消息(d onebot.MQEvent) int {

	// api.A输出日志("收到讨论组->" + d.MQ_消息来源 + " 成员->" + d.MQ_触发对象_主动 + "的信息:" + d.MQ_消息内容)
	return consts.MT_消息处理_继续
}

func 收到群临时会话(d onebot.MQEvent) int {

	// api.A输出日志("收到临时会话->" + d.MQ_触发对象_主动 + " 在->" + d.MQ_消息来源 + "发起的会话信息:" + d.MQ_消息内容)
	return consts.MT_消息处理_继续
}

func 收到机器人发出消息(d onebot.MQEvent) int {

	return consts.MT_消息处理_继续
}

// 吉祥物函数
func main() {
}
