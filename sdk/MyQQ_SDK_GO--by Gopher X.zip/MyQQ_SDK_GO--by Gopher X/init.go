//
// 如果不确定，请勿修改本文件内容
//

package main

import (
	"encoding/json"
	"go_code/MyQQ_SDK_GO/bin/api"
	"go_code/MyQQ_SDK_GO/bin/consts"
	"go_code/MyQQ_SDK_GO/bin/core"
	"go_code/MyQQ_SDK_GO/bin/onebot"
	"os"
)

func init() {
	core.Info = Info
	core.Event = Event
	core.MQSet = MQSet
	core.MQEnd = MQEnd
	初始化函数()
}

func 初始化应用目录() string {
	dir, err := os.Getwd()
	if err != nil {
		api.A输出日志(err.Error())
		return ""
	}
	return dir + "/data/plugin/" + 插件名称
}

type PluginInfo struct {
	Name        string `json:"name"`
	Author      string `json:"author"`
	Description string `json:"description"`
	Version     string `json:"version"`
	Skey        string `json:"skey"`
	Sdk         string `json:"sdk"`
}

func Info() string {
	/*pluginInfo := fmt.Sprintf("插件名称{%s}\n插件版本{%s}\n插件作者{%s}\n插件说明{%s}\n插件skey{%s}\n插件sdk{%s}",
	PluginName, PluginVer, PluginAuthor, PluginDesc, PluginSkey, PluginSDK)*/

	//插件Skey
	PluginSkey := "SDG5D4Ys89h7DJ849d"
	//插件SDK
	PluginSDK := "S1"

	pluginInfo := PluginInfo{
		Name:        插件名称,
		Author:      插件作者,
		Description: 插件说明,
		Version:     插件版本,
		Skey:        PluginSkey,
		Sdk:         PluginSDK,
	}
	bytes, _ := json.Marshal(pluginInfo)
	return string(bytes)
}

// SelfID 机器人QQ, 多Q版用于判定哪个QQ接收到该消息
// MessageType 消息类型, 接收到消息类型，该类型可在常量表中查询具体定义，此处仅列举： -1 未定义事件 0,在线状态临时会话 1,好友信息 2,群信息 3,讨论组信息 4,群临时会话 5,讨论组临时会话 6,财付通转账 7,好友验证回复会话
// SubType 消息子类型, 此参数在不同消息类型下，有不同的定义，暂定：接收财付通转账时 1为好友 4为群临时会话 5为讨论组临时会话    有人请求入群时，不良成员这里为1
// GroupID 消息来源, 此消息的来源，如：群号、讨论组ID、临时会话QQ、好友QQ等
// UserID 触发对象_主动, 主动发送这条消息的QQ，踢人时为踢人管理员QQ
// NoticeID 触发对象_被动, 被动触发的QQ，如某人被踢出群，则此参数为被踢出人QQ
// Message 消息内容, 此参数有多重含义，常见为：对方发送的消息内容，但当消息类型为 某人申请入群，则为入群申请理由
// MessageNum 消息序号, 此参数暂定用于消息回复，消息撤回
// MessageID 消息ID, 此参数暂定用于消息回复，消息撤回
// RawMessage 原始信息, UDP收到的原始信息，特殊情况下会返回JSON结构（入群事件时，这里为该事件seq）
// Ret 回传文本指针, 此参数用于插件加载拒绝理由
func Event(selfID int64, mseeageType int, subType int, groupID int64, userID int64, noticeID int64, message string, messageNum int64, messageID int64, seq string, ret int32, retChan chan<- int) {
	xe := onebot.MQEvent{
		MQ_机器人QQ:        selfID,
		MQ_消息类型:         mseeageType,
		MQ_消息子类型:        subType,
		MQ_消息来源:         groupID,
		MQ_触发对象_主动:      userID,
		MQ_触发对象_被动:      noticeID,
		MQ_消息内容:         message,
		MQ_消息序号:         messageNum,
		MQ_消息ID:         messageID,
		MQ_原始信息:         seq,
		MQ_信息回传文本指针_Out: ret,
	}
	var res int = consts.MT_消息处理_继续

	switch mseeageType {

	// 框架事件
	case consts.MT_框架_框架加载完成:
		res = onebot.ProtectRun(func() int { return 框架加载完成(xe) }, "框架加载完成()")
	case consts.MT_框架_框架即将重启:
		res = onebot.ProtectRun(func() int { return 框架即将重启(xe) }, "框架即将重启()")
	// 插件事件
	case consts.MT_插件_本插件载入:
		res = onebot.ProtectRun(func() int { return 本插件载入(xe) }, "本插件载入()")
	case consts.MT_插件_插件被启用:
		res = onebot.ProtectRun(func() int { return 插件被启用(xe) }, "插件被启用()")
	case consts.MT_插件_插件被禁用:
		res = onebot.ProtectRun(func() int { return 插件被禁用(xe) }, "插件被禁用()")
	case consts.MT_插件_插件被点击:
		res = onebot.ProtectRun(func() int { return 插件被点击(xe) }, "插件被点击()")
		// 常用消息事件
	case consts.MT_常用消息_好友:
		res = onebot.ProtectRun(func() int { return 收到好友消息(xe) }, "收到好友消息()")
	case consts.MT_常用消息_群:
		res = onebot.ProtectRun(func() int { return 收到群消息(xe) }, "收到群消息()")
	case consts.MT_常用消息_讨论组:
		res = onebot.ProtectRun(func() int { return 收到讨论组消息(xe) }, "收到讨论组消息()")
	case consts.MT_常用消息_群临时会话:
		res = onebot.ProtectRun(
			func() int {
				return 收到群临时会话(xe)
			},
			"收到群临时会话()")
	case consts.MT_其他_机器人发出消息:
		res = onebot.ProtectRun(
			func() int {
				return 收到机器人发出消息(xe)
			},
			"()")
	case consts.MT_好友_被单向添加好友:
		res = onebot.ProtectRun(
			func() int {
				return 被单向添加好友(xe)
			},
			"()")
	case consts.MT_好友_被请求添加好友:
		res = onebot.ProtectRun(
			func() int {
				return 被请求添加好友(xe)
			},
			"()")
	case consts.MT_好友_被同意加为好友:
		res = onebot.ProtectRun(
			func() int {
				return 被同意加为好友(xe)
			},
			"()")
	case consts.MT_好友_被拒绝加为好友:
		res = onebot.ProtectRun(
			func() int {
				return 被拒绝加为好友(xe)
			},
			"()")
	case consts.MT_好友_好友状态改变:
		res = onebot.ProtectRun(
			func() int {
				return 好友状态改变(xe)
			},
			"()")
	case consts.MT_好友_被删除好友:
		res = onebot.ProtectRun(
			func() int {
				return 被删除好友(xe)
			},
			"()")
	case consts.MT_好友_好友签名变更:
		res = onebot.ProtectRun(
			func() int {
				return 好友签名变更(xe)
			},
			"()")
	case consts.MT_群_某人申请加入群:
		res = onebot.ProtectRun(
			func() int {
				return 某人申请加入群(xe)
			},
			"()")
	case consts.MT_群_某人被邀请加入群:
		res = onebot.ProtectRun(
			func() int {
				return 某人被邀请加入群(xe)
			},
			"()")
	case consts.MT_群_我被邀请加入群:
		res = onebot.ProtectRun(
			func() int {
				return 我被邀请加入群(xe)
			},
			"()")
	case consts.MT_群_某人已被邀请入群:
		res = onebot.ProtectRun(
			func() int {
				return 某人已被邀请入群(xe)
			},
			"()")
	case consts.MT_群_某人被批准加入了群:
		res = onebot.ProtectRun(
			func() int {
				return 某人被批准加入了群(xe)
			},
			"()")
	case consts.MT_群_某人退出群:
		res = onebot.ProtectRun(
			func() int {
				return 某人退出群(xe)
			},
			"()")
	case consts.MT_群_某人被管理移除群:
		res = onebot.ProtectRun(
			func() int {
				return 某人被管理移除群(xe)
			},
			"()")
	case consts.MT_群_某群被解散:
		res = onebot.ProtectRun(
			func() int {
				return 某群被解散(xe)
			},
			"()")
	case consts.MT_群_某人成为管理:
		res = onebot.ProtectRun(
			func() int {
				return 某人成为管理(xe)
			},
			"()")
	case consts.MT_群_某人被取消管理:
		res = onebot.ProtectRun(
			func() int {
				return 某人被取消管理(xe)
			},
			"()")
	case consts.MT_群_群名片变动:
		res = onebot.ProtectRun(
			func() int {
				return 群名片变动(xe)
			},
			"()")
	case consts.MT_群_群名变动:
		res = onebot.ProtectRun(
			func() int {
				return 群名变动(xe)
			},
			"()")
	case consts.MT_群_群公告变动:
		res = onebot.ProtectRun(
			func() int {
				return 群公告变动(xe)
			},
			"()")
	case consts.MT_好友_说说被评论:
		res = onebot.ProtectRun(
			func() int {
				return 说说被评论(xe)
			},
			"()")
	case consts.MT_好友_好友正在输入:
		res = onebot.ProtectRun(
			func() int {
				return 好友正在输入(xe)
			},
			"()")
	case consts.MT_好友_好友今天首次发起会话:
		res = onebot.ProtectRun(
			func() int {
				return 好友今天首次发起会话(xe)
			},
			"()")
	case consts.MT_好友_被好友抖动:
		res = onebot.ProtectRun(
			func() int {
				return 被好友抖动(xe)
			},
			"()")
	case consts.MT_好友_好友文件接收:
		res = onebot.ProtectRun(
			func() int {
				return 好友文件接收(xe)
			},
			"()")
	case consts.MT_群_群文件接收:
		res = onebot.ProtectRun(
			func() int {
				return 群文件接收(xe)
			},
			"()")
	case consts.MT_群_对象被禁言:
		res = onebot.ProtectRun(
			func() int {
				return 对象被禁言(xe)
			},
			"()")
	case consts.MT_群_对象被解除禁言:
		res = onebot.ProtectRun(
			func() int {
				return 对象被解除禁言(xe)
			},
			"()")
	case consts.MT_群_群管开启全群禁言:
		res = onebot.ProtectRun(
			func() int {
				return 群管开启全群禁言(xe)
			},
			"()")
	case consts.MT_群_群管关闭全群禁言:
		res = onebot.ProtectRun(
			func() int {
				return 群管关闭全群禁言(xe)
			},
			"()")
	case consts.MT_群_群管开启匿名聊天:
		res = onebot.ProtectRun(
			func() int {
				return 群管开启匿名聊天(xe)
			},
			"()")
	case consts.MT_群_群管关闭匿名聊天:
		res = onebot.ProtectRun(
			func() int {
				return 群管关闭匿名聊天(xe)
			},
			"()")
	case consts.MT_好友_好友撤回消息:
		res = onebot.ProtectRun(
			func() int {
				return 好友撤回消息(xe)
			},
			"()")
	case consts.MT_群_群撤回消息:
		res = onebot.ProtectRun(
			func() int {
				return 群撤回消息(xe)
			},
			"()")
	case consts.MT_好友_好友视频接收:
		res = onebot.ProtectRun(
			func() int {
				return 好友视频接收(xe)
			},
			"()")
	case consts.MT_群_群视频接收:
		res = onebot.ProtectRun(
			func() int {
				return 群视频接收(xe)
			},
			"()")
	case consts.MT_好友_好友语音接收:
		res = onebot.ProtectRun(
			func() int {
				return 好友语音接收(xe)
			},
			"()")
	case consts.MT_群_群语音接收:
		res = onebot.ProtectRun(
			func() int {
				return 群语音接收(xe)
			},
			"()")
	case consts.MT_群_群消息被设置为精华:
		res = onebot.ProtectRun(
			func() int {
				return 群消息被设置为精华(xe)
			},
			"()")
	case consts.MT_群_群消息被取消精华:
		res = onebot.ProtectRun(
			func() int {
				return 群消息被取消精华(xe)
			},
			"()")
	case consts.MT_财富_收到财付通转账:
		res = onebot.ProtectRun(
			func() int {
				return 收到财付通转账(xe)
			},
			"()")
	case consts.MT_财富_收到群聊红包:
		res = onebot.ProtectRun(
			func() int {
				return 收到群聊红包(xe)
			},
			"()")
	case consts.MT_财富_收到私聊红包:
		res = onebot.ProtectRun(
			func() int {
				return 收到私聊红包(xe)
			},
			"()")
	case consts.MT_财富_群聊红包被领取:
		res = onebot.ProtectRun(
			func() int {
				return 群聊红包被领取(xe)
			},
			"()")
	case consts.MT_财富_私聊红包被领取:
		res = onebot.ProtectRun(
			func() int {
				return 私聊红包被领取(xe)
			},
			"()")
	case consts.MT_框架QQ_添加了一个新的帐号:
		res = onebot.ProtectRun(
			func() int {
				return 添加了一个新的帐号(xe)
			},
			"()")
	case consts.MT_框架QQ_QQ登录完成:
		res = onebot.ProtectRun(
			func() int {
				return QQ登录完成(xe)
			},
			"()")
	case consts.MT_框架QQ_QQ被手动离线:
		res = onebot.ProtectRun(
			func() int {
				return QQ被手动离线(xe)
			},
			"()")
	case consts.MT_框架QQ_QQ被强制离线:
		res = onebot.ProtectRun(
			func() int {
				return QQ被强制离线(xe)
			},
			"()")
	case consts.MT_框架QQ_QQ长时间无响应或掉线:
		res = onebot.ProtectRun(
			func() int {
				return QQ长时间无响应或掉线(xe)
			},
			"()")
	case consts.MT_其他_其他设备上线:
		res = onebot.ProtectRun(
			func() int {
				return 其他设备上线(xe)
			},
			"()")
	case consts.MT_其他_其他设备下线:
		res = onebot.ProtectRun(
			func() int {
				return 其他设备下线(xe)
			},
			"()")
	case consts.MT_常用消息_未定义:
		res = onebot.ProtectRun(
			func() int {
				return 未定义(xe)
			},
			"()")
	//case consts.MT_好友_:
	//	res = onebot.ProtectRun(
	//		func() int {
	//			return f(xe)
	//		},
	//		"()")

	// 消息事件
	default:
		res = consts.MT_消息处理_继续
		//
	}

	retChan <- res

}

func MQEnd() int64 {
	return 0
}

func MQSet() int64 {
	go 设置被按下()
	return 0
}
