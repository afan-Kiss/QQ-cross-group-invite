package main

import (
	//"fmt"
	//"go_code/MyQQ_SDK_GO/bin/api"
	"go_code/MyQQ_SDK_GO/bin/consts"
	"go_code/MyQQ_SDK_GO/bin/onebot"
)

// 框架事件
func 框架加载完成(xe onebot.MQEvent) int {
	//api.A输出日志(fmt.Sprintf("%s | 接收到一条【%d】类型消息 | %s", 插件名称, xe.MessageType, xe.Message))
	return consts.MT_消息处理_继续
}
func 框架即将重启(xe onebot.MQEvent) int {
	//api.A输出日志(fmt.Sprintf("%s | 接收到一条【%d】类型消息 | %s", 插件名称, xe.MessageType, xe.Message))
	return consts.MT_消息处理_继续
}

// 插件事件
func 本插件载入(xe onebot.MQEvent) int {
	//api.A输出日志(fmt.Sprintf("%s | 接收到一条【%d】类型消息 | %s", 插件名称, xe.MessageType, xe.Message))
	return consts.MT_事件处理_同意
}
func 插件被启用(xe onebot.MQEvent) int {
	//api.A输出日志(fmt.Sprintf("%s | 接收到一条【%d】类型消息 | %s", 插件名称, xe.MessageType, xe.Message))
	return consts.MT_事件处理_同意
}
func 插件被禁用(xe onebot.MQEvent) int {
	//api.A输出日志(fmt.Sprintf("%s | 接收到一条【%d】类型消息 | %s", 插件名称, xe.MessageType, xe.Message))
	return consts.MT_事件处理_同意
}
func 插件被点击(xe onebot.MQEvent) int {
	//点击方式参考子类型.  1=左键单击 2=右键单击 3=左键双击
	//api.A输出日志(fmt.Sprintf("%s | 接收到一条【%d】类型消息 | %s", 插件名称, xe.MessageType, xe.Message))
	return consts.MT_事件处理_同意
}
