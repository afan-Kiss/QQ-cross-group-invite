'''
利用MyQQ的httpapi的py版本，需要先阅读https://www.kancloud.cn/daen/myqq/2233673,请随意删改
完成后直接运行该py文件，保持py和MyQQ同时运行
https://www.kancloud.cn/daen/myqq/2233670
'''
from http.server import HTTPServer, BaseHTTPRequestHandler
import requests as rq
from urllib import parse


class Resquest(BaseHTTPRequestHandler):
    def do_POST(self):
        raw_recv_data = self.rfile.read(int(self.headers['content-length'])).decode()
        #转换成dict类型
        self.recv_data = eval(raw_recv_data)
        #受到的消息要进行url解码，不然可能看不懂，如下
        recv_msg = parse.unquote(self.recv_data['MQ_msg'])
        print(recv_msg)
        
        #在这里对收到的数据进行处理，得到最终params
        #模板，参考api列表
        params = {
            'function':'Api_SendMsg', 
            'token':'110',  #记得修改成自己的
            'c1':'1973989081',
            'c2':1,
            'c3':'',
            'c4':'1139923500',
            'c5':'q',
            }

        url = 'http://localhost:8889/MyQQHTTPAPI' #从MyQQ的http插件复制
        rp = rq.get(url, params=params)
        print(rp.content.decode('utf-8')) #结果MyQQ反馈

if __name__ == '__main__':
    host = ('', 8888)   #回调地址http://127.0.0.1:8888/
    server = HTTPServer(host, Resquest)
    print("Starting server, listen at: %s:%s" % host)
    server.serve_forever()

#更多玩法请参考api列表自定义
