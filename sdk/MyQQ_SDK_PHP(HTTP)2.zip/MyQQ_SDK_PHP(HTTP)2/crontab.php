<?php
// 定时任务
// 调用：http://ip/crontab.php?s=c-water
include "qqbot.class.php";
$MQ_Api = new qqbotTopSdk;
if ($_GET['s'] == 'c-water') {
    $waterHttp = file_get_contents('http://api.k780.com/?app=weather.today&weaId=2870&appkey=10003&sign=b59bc3ef6191eb9f747dd4e83c99f2a4&format=json');
    $json = json_decode($waterHttp, true)['result'];
    $msg = "{$json['days']} {$json['week']} {$json['weather']}\n{$json['wind']} {$json['winp']}\n温度区间:{$json['temperature']}\n当前温度:{$json['temperature_curr']}\n湿度:{$json['humidity']}";
    $back =  $MQ_Api->Api_QQBOT('Api_SendMsg', ['123456', '1', '', '123456', $msg]);
    print_r($back);
}
