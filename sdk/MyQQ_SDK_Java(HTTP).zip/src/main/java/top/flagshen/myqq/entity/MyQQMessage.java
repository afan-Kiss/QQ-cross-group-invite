package top.flagshen.myqq.entity;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author 小棽
 * @date 2021/6/20 19:43
 */
public class MyQQMessage {
    @JsonProperty("MQ_robot")
    private String mqRobot;
    @JsonProperty("MQ_type")
    private Integer mqType;
    @JsonProperty("MQ_type_sub")
    private Integer mqTypeSub;
    @JsonProperty("MQ_fromID")
    private String mqFromid;
    @JsonProperty("MQ_fromQQ")
    private String mqFromqq;
    @JsonProperty("MQ_passiveQQ")
    private String mqPassiveqq;
    @JsonProperty("MQ_msg")
    private String mqMsg;
    @JsonProperty("MQ_msgSeq")
    private String mqMsgseq;
    @JsonProperty("MQ_msgID")
    private String mqMsgid;
    @JsonProperty("MQ_msgData")
    private String mqMsgdata;

    public String getMqRobot() {
        return mqRobot;
    }

    public void setMqRobot(String mqRobot) {
        this.mqRobot = mqRobot;
    }

    public Integer getMqType() {
        return mqType;
    }

    public void setMqType(Integer mqType) {
        this.mqType = mqType;
    }

    public Integer getMqTypeSub() {
        return mqTypeSub;
    }

    public void setMqTypeSub(Integer mqTypeSub) {
        this.mqTypeSub = mqTypeSub;
    }

    public String getMqFromid() {
        return mqFromid;
    }

    public void setMqFromid(String mqFromid) {
        this.mqFromid = mqFromid;
    }

    public String getMqFromqq() {
        return mqFromqq;
    }

    public void setMqFromqq(String mqFromqq) {
        this.mqFromqq = mqFromqq;
    }

    public String getMqPassiveqq() {
        return mqPassiveqq;
    }

    public void setMqPassiveqq(String mqPassiveqq) {
        this.mqPassiveqq = mqPassiveqq;
    }

    public String getMqMsg() {
        return mqMsg;
    }

    public void setMqMsg(String mqMsg) {
        this.mqMsg = mqMsg;
    }

    public String getMqMsgseq() {
        return mqMsgseq;
    }

    public void setMqMsgseq(String mqMsgseq) {
        this.mqMsgseq = mqMsgseq;
    }

    public String getMqMsgid() {
        return mqMsgid;
    }

    public void setMqMsgid(String mqMsgid) {
        this.mqMsgid = mqMsgid;
    }

    public String getMqMsgdata() {
        return mqMsgdata;
    }

    public void setMqMsgdata(String mqMsgdata) {
        this.mqMsgdata = mqMsgdata;
    }
}
