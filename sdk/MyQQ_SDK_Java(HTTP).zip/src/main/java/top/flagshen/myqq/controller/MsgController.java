package top.flagshen.myqq.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import top.flagshen.myqq.common.TypeConstant;
import top.flagshen.myqq.common.XiaoshenTemplate;
import top.flagshen.myqq.entity.DataResult;
import top.flagshen.myqq.entity.MyQQMessage;
import top.flagshen.myqq.entity.ReqResult;

import javax.servlet.http.HttpServletRequest;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;

/**
 * @author 小棽
 * @date 2021/6/20 19:45
 */
@RequestMapping("/msg")
@RestController
public class MsgController {

    private final XiaoshenTemplate xsTemplate;

    public MsgController(XiaoshenTemplate xsTemplate) {
        this.xsTemplate = xsTemplate;
    }

    @PostMapping
    public ReqResult newMsg(@RequestBody MyQQMessage message, HttpServletRequest request) throws Exception {
        message.setMqMsg(URLDecoder.decode(message.getMqMsg(), "utf-8"));
        String mqMsg = message.getMqMsg();
        switch (message.getMqType()) {
            case TypeConstant.MSGTYPE_NODEFINE://消息类型_未定义
                break;
            case TypeConstant.MSGTYPE_FRIEDN://消息类型_好友
                //发送好友消息
                Map<String, Object> dataResult = xsTemplate.sendMsgEx(message.getMqRobot(),
                        0, TypeConstant.MSGTYPE_FRIEDN,
                        null, message.getMqFromqq(), "您发送了:" + mqMsg);
                if ("获取好友列表".equals(mqMsg)) {
                    //获取好友列表
                    Map<String, Object> map = new HashMap<>();
                    map.put("c1", message.getMqRobot());
                    Map<String, Object> friendsMap = xsTemplate.tongyongPost("Api_GetFriendList", map);
                    System.out.println(friendsMap);
                }
                break;
            case TypeConstant.MSGTYPE_GROUP://消息类型_群
                break;
        }
        return new ReqResult(1);
    }
}
