package main

func main()  {
	
}

func onStart() {

	MessageBoxPlain("启动结果", "熊猫综合营销wx: XMSC63插件启动成功")
	select {

	}
}