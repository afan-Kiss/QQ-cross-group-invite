import requests
s = requests.Session()
params = {
        'function': 'Api_GetOnlineQQlist',#开发文档
        'token': '110',
    }
url = 'http://localhost:7071/MyQQHTTPAPI'  # 从MyQQ的http插件复制
rp = s.get(url, params=params)
a = rp.json()

##不用http沟通，如果使用只需要一次：
'''
class Resquest(BaseHTTPRequestHandler):
    def do_POST(self):

HTTPServer(host,Resquest).handle_request()# 只调用一次
HTTPServer(host, Resquest).serve_forever()#一直监听（没有任何必要）
'''